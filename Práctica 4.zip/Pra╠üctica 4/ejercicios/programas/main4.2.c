#include <stdio.h>
#include <stdlib.h>

int total;
int exponencial();

int main(int argc, char *argv[])
{
  int N, a;
  
  printf("este programa resuelve el polinomio 1^1 + 2^2 + 3^3 + ... N^N\n");
  printf("ingrese un numero: ");
  scanf("%i", &N);
  a=exponencial(N);
  printf("el resultado es: %i\n", a);
  
  system("PAUSE");	
  return 0;
}
 
int exponencial(int N){
    int total, i;
    total=1;
            for(i=0;i<=N;i++){
                   if(i%2==0){
                   total=total-pow(i,i);
                   }          
                   else{
                   total=total+pow(i,i);
                   }                             
                             
            }                
               return total;   
    
    
}
