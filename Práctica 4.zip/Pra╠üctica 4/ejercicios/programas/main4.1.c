#include <stdio.h>
#include <stdlib.h>
int funcion();

int i;
int volumen[2];
int alto[2], ancho[2], longitud[2];

int main(int argc, char *argv[]) {
		for(i=0;i<3;i++){
			printf("\nValores de la habitacion %d\n", i+1);
			printf("Alto: ");
			scanf("%i", &alto[i]);
			printf("Ancho: ");
			scanf("%i", &ancho[i]);
			printf("Longitud: ");
			scanf("%i", &longitud[i]);
            volumen[i]=funcion(alto,ancho,longitud);
		}
		printf("\n");			
			
		for(i=0;i<3;i++){

			printf("Volumen de la habitacion %d: %i\n", i+1, volumen[i]);
		}
	system("PAUSE");	
	return 0;
}


int funcion(int alto[i], int ancho[i], int longitud[i]){
			volumen[i]=alto[i]*(ancho[i]*longitud[i]);
			return volumen[i];
}
