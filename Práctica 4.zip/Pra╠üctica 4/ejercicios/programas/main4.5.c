#include <stdio.h>
#include <stdlib.h>
double hipotenusa[2], lado1, lado2;
int i, a;

double hipotenus(double lado1, double lado2){	
	a=pow(lado1,2)+pow(lado2,2);
	hipotenusa[i]=sqrt(a);
	return hipotenusa[i];
}

int main(int argc, char *argv[]) {
	printf("Este programa calcula la hipotenusa de tres triangulos\n");
	for(i=0;i<3;i++){
		printf("triangulo %i:\n", i);
		printf("lado 1: ");
		scanf("%d", &lado1);
		printf("lado 2: ");
		scanf("%d", &lado2);
		hipotenus(lado1, lado2);
	}
	for(i=0;i<3;i++){
		printf("hipotenusa %i: %d", i+1, hipotenusa[i]);
	}
		
	
	return 0;
}
