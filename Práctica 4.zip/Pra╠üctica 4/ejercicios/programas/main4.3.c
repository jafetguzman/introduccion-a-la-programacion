#include <stdio.h>
#include <stdlib.h>
float potencia(float base, float exponente);
float potencial;
int main(int argc, char *argv[])
{
  float base, exponente;
      printf("introduzca los numeros para efectuar la operacion\n");
      printf("base: ");
      scanf("%f", &base);
      printf("exponente: ");
      scanf("%f", &exponente);
      potencia(base, exponente);
      printf("el resultado es= %.2f\n", potencial);                      
  system("PAUSE");	
  return 0;
}

float potencia(float base, float exponente){
      potencial=pow(base,exponente);
      return potencial;
}
