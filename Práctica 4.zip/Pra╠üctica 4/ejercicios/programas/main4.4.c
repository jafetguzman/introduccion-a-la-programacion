#include <stdio.h>
#include <stdlib.h>
float resistencia, voltaje, corriente;
float calcular_resistencia(float voltaje, float corriente){

	printf("valor del voltaje: ");
	scanf("%f", &voltaje);
	printf("valor de la corriente: ");
	scanf("%f", &corriente);
	resistencia=voltaje/corriente;
	return resistencia;
}
float calcular_voltaje(float resistencia, float corriente){

 	printf("valor de la corriente: ");
	scanf("%f", &corriente);
	printf("valor de la resistencia: ");
	scanf("%f", &resistencia);
	voltaje=resistencia*corriente;
	return voltaje;
}
float calcular_corriente(float resistencia, float voltaje){

	printf("valor del voltaje: ");
	scanf("%f", &voltaje);
 	printf("valor de la corriente: ");
	scanf("%f", &corriente);
	corriente=voltaje/resistencia;
	return corriente;
}



int main(int argc, char *argv[]) {
	int m;
	printf("Que quiere calcular?\n");
	printf("1) Resistencia\n");
	printf("2) Voltaje\n");
	printf("3) Corriente\n");
	scanf("%i", &m);
	switch (m){
		case 1:
			calcular_resistencia(voltaje, corriente);
			printf("la resistencia es igual a: %f\n", resistencia); break;
		case 2:
			calcular_voltaje(corriente, resistencia);
			printf("El voltaje es igual a: %f\n", voltaje); break;
		case 3:
			calcular_corriente(voltaje, resistencia);
			printf("La corriente es igual a: %f", corriente); break;
		default:
			printf("ERROR");		
	}	
	system("PAUSE");
	return 0;
}







